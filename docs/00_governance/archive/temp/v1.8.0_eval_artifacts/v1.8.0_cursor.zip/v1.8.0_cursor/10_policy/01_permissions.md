# 1. 헌법 (7개 조항, 절대 원칙)

**원본 출처**: v1.7.1 §1 + §24-6-1 (250–426 + 2796–2866)
**v1.8.0 Layer**: Policy
**의존**: `00_core/01_primary.md`
**변경 이력**: 본 파일은 v1.7.1 §1 + §24-6-1 원본 전문 이관본. 텍스트 변경 없음.
**파일 경로**: `docs/00_governance/architecture/v1.8.0_cursor/10_policy/01_permissions.md`

---

# 1. 헌법 (7개 조항, 절대 원칙)

헌법은 모든 설계 결정의 최상위 기준이다. 어떤 모듈·알고리즘·UX·비즈니스 결정도 이 7개 조항을 위반하면 즉시 폐기한다. **헌법은 토론 대상이 아니라 검증 대상이다.**

v1.3의 5개 조항을 100% 계승하고, v1.4에서 3조 정정·4조·6조 신설, v1.6에서 7조(디바이스 오리엔티드 거위) 명문화로 현재 **7개 조항** 체계.

## 제1조 — Out-Bound Zero (사용자 데이터 외부 전송 금지)

사용자의 통화 기록, 연락처, SMS, 사용자 행동, 통화 상대 번호 등 **일체의 사용자 데이터는 우리(올랑방)가 운영하는 서버 또는 제3자 서버로 전송되지 않는다.** 모든 처리는 디바이스 내에서 완결된다.

**해석 규칙**:
- "우리 서버" = 올랑방이 운영하는 AWS Lambda, API Gateway, 자체 DB, 자체 영수증 검증 서버 등.
- "제3자 서버" = 사용자 데이터를 수집·분석하는 목적의 상용 서비스.
- **허용**: 일반 검색 엔진(Google·Bing 등)에 번호를 조회하는 행위 자체는 Out-Bound로 보지 않는다(사용자 데이터가 아니라 공개 번호이므로). 단 응답 원문은 제2조에 따라 즉시 폐기.
- **허용**: 스토어 공식 API(Google Play Billing, StoreKit 2)에 영수증 확인 요청은 허용(스토어 자체가 결제 인프라).
- **허용**: 공공 공신력 API(KISA·경찰청·금감원) 조회는 허용(정부 공공 데이터).

v1.3 이래 불변. 절대 원칙.

## 제2조 — In-Bound Zero (외부 원문 영구 저장 금지)

디바이스가 외부 검색 엔진에서 받은 HTML, JSON, 검색 스니펫 등 **일체의 외부 원문은 메모리에서만 처리되고 즉시 폐기된다.** 디바이스 NKB(Number Knowledge Base)에는 원문이 아닌 **가공된 신호 카운트(featureCounts)만 저장된다.** rawSnippet 200자 등 어떤 형태의 부분 저장도 금지된다.

**해석 규칙**:
- 외부 HTML·JSON·텍스트 스니펫 → 메모리 내 분석 후 폐기
- featureCounts (예: `{SCAM_KEYWORD: 12, AD_KEYWORD: 3}`) → NKB 저장 가능
- 사용자 번호 E.164 식별자 → NKB 저장 가능 (식별자일 뿐 외부 원문 아님)

v1.3 이래 불변. 절대 원칙.

## 제3조 — 결정권 중앙집중 금지 (Decision Centralization Prohibited)

본 시스템은 **모든 판단의 결정권이 중앙(우리 서버·본사)에 집중되는 것을 금지한다.** 디바이스는 스스로 판단하는 1차 결정 주체이며, 중앙은 참고 신호와 업데이트만 제공할 수 있다.

### 3-1. 금지 대상 (해석 여지 없음)

- 중앙 서버가 "최종 정답"을 내려주는 구조 (예: 본사 API가 "이 번호 = 스팸"을 응답)
- 특정 입력 → 특정 출력이 중앙에 하드코딩된 결정 매핑 (예: "한국 SIM = 네이버 검색")
- 디바이스가 중앙 응답 없이는 판단 불가능한 구조 (예: NKB Miss 시 본사 fallback)

### 3-2. 허용 대상 (해석 여지 없음)

- 검색 엔진 **시드(seed) 후보 리스트**를 디바이스에 빌드 시 포함 (probe 대상 후보일 뿐, 매핑 아님)
- 키워드 사전 업데이트 (strings.xml의 scamKeywords 등 — 정적 데이터)
- Tier 가중치 업데이트 (Tier 1~4 검색 결과 신뢰도 — 정적 데이터)
- 모델 가중치 업데이트 (Softmax 가중치 — 정적 데이터)

**핵심 판별축**: "최종 결정을 누가 내리는가?"
- 중앙이 "이 번호는 스팸이다"를 내리면 → 위반
- 디바이스가 "내가 이 번호에 대해 probe한 결과 + 로컬 학습 결과 = 스팸"을 내리면 → 준수

v1.3 원문은 "No Curation: 본사 큐레이션 데이터 주입 금지"였다. v1.4에서 해석 여지를 제거하여 현행 조문으로 정정.

## 제4조 — 자가 작동 (Self-Operation)

본 시스템은 **중앙 없이도 멈추지 않는 상태**를 유지한다. 네트워크 단절, 서버 응답 실패, 공공 API 장애 등 어떤 외부 요인으로도 사용자의 기본 가치는 손실되지 않는다.

### 4-1. SLA 4단계 (자가 작동의 운영 정의)

| 레벨 | 상태 | 네트워크 | 외부 API | NKB | 사용자 경험 |
|---|---|---|---|---|---|
| L1 Full | 정상 | 연결 | 가용 | 가용 | 4속성 출력 + 실시간 probe 갱신 |
| L2 Degraded | 부분 장애 | 연결 | 일부 장애 | 가용 | 4속성 출력 (stale 플래그) |
| L3 Offline | 오프라인 | 단절 | 불가 | 가용 | **4속성 출력 (NKB Hit만)** ← **기준선** |
| L4 Catastrophic | NKB 손상 | 단절 | 불가 | 손상 | Cold Start 재실행 또는 기본값 반환 |

**헌법 기준선 = L3.** 즉 사용자가 어떤 환경에 있어도 L3 이상 경험이 보장되어야 한다. L4는 극단 상황이며 Cold Start 자가 복구 경로가 반드시 존재해야 한다.

### 4-2. L3에서 거위가 멈추지 않는 근거

- NKB는 디바이스 Local Room DB → 네트워크 없이도 조회 가능
- 4속성 출력은 NKB Hit만으로 산출 가능 (§8-6)
- Self-Discovery 결과(ClusterProfile)는 NKB에 영구 저장 → probe 실패해도 기존 값 사용

v1.4_disc 신설 조항.

## 제5조 — 정직성 (Honesty)

본 시스템은 **모든 설계 결정, 폐기 이력, 한계, 검증 결과를 문서화한다.** 숨기지 않는다.

### 5-1. 구체 의무

- 모든 패치(Patch NN)의 Before/After 본문을 문서에 포함한다 (§0-B-2).
- 외부 검증자 지적 사항을 숨기지 않고 채택·거부 사유와 함께 기록한다 (§0-B-1).
- 검증 불가 한계를 명시한다 (§0-D).
- 토론 과정에서 폐기된 안을 제안자 실명과 함께 기록한다 (§0-2).
- 사용자에게 "확실하지 않음"을 숨기지 않는다 (ambiguous 플래그, §8-1).

### 5-2. 위반 판정

- "추정 금지" 위반 (근거 없는 수치 주장)
- 외부 검증자 지적을 본문에 반영하지 않고 요약으로만 처리
- 패치 이력 누락
- 한계 로그 누락

v1.3 원문 계승. v1.4에서 구체 의무와 위반 판정을 명문화.

## 제6조 — 가격 정직성 (Pricing Honesty)

본 시스템의 가격은 **net 기준으로 측정·공개**한다. Apple/Google 수수료 30%, 부가세(VAT) 평균 10%, 환불 5%를 반영한 net ARPU를 KPI로 사용한다.

### 6-1. 현재 확정 가격

- **공식 구독료**: USD 2.49/월 단일 가격, 전세계 동일, 연간 가격 없음 (2026-04-22 대표님 확정)
- **net ARPU 계산**: gross $2.49 × (1 - 0.30 스토어) × (1 - 0.10 VAT) × (1 - 0.05 환불) ≈ **$1.49/월**
- **국가당 break-even MAU**: 월 $100K net 목표 / $1.49 = **67,114명 / 국가당** (전환율 3% 가정 시 MAU 2.24M)

### 6-2. 가격 변경 원칙

- KPI 매핑을 거부하지 않는다 (헌법 3조와 구분: KPI는 측정 도구이지 중앙 결정이 아니다).
- 가격은 대표님 승인 사항. 헌법 6조는 "정직한 측정"을 강제하지 "가격 자체"를 고정하지 않는다.
- 변경 시 0-A-2 가격 정책 변경 이력에 기록.

v1.4_disc 신설. v1.6.1에서 $2.49 확정 (본 v1.6.2 승계).

## 제7조 — 디바이스 오리엔티드 거위 (Device-Oriented Goose)

본 시스템은 **디바이스가 황금알을 낳는 거위**라는 은유를 설계 원칙으로 삼는다.

### 7-1. 비유의 정의

- **거위** = 디바이스 (온디바이스 Decision Engine + NKB + Self-Discovery)
- **황금알** = 사용자가 받는 판단 결과 (4속성: 위험도, 예상 손해, 손해 유형, 이유 설명)
- **거위를 잡는 행위** = 본사 서버로 사용자 데이터 수집, 중앙 매핑, 폐쇄형 판단 (1~3조 위반)
- **거위가 자가 증식** = NKB Self-Evolution, ClusterProfile 자가 생성 (§12)

### 7-2. 구현 원칙

- **본사 운영 0, 본사 매핑 0, 본사 데이터센터 0** (메모리 헌법 7대 원칙)
- 디바이스 = 모든 것 (검색·분석·판단·저장·학습 전부 온디바이스)
- 외부는 입력 소스일 뿐, 판단의 주체가 아니다 (제3조)
- 멀티 Surface 확장은 엔진을 N개로 늘리는 것이 아니라 **단일 엔진의 Surface를 N개로 늘리는 것** (§17 One Engine, N Surfaces)

### 7-3. 금지 구현 패턴

- 본사가 "사용자 번호 DB"를 운영하는 구조 → 위반
- 본사가 "이 번호 = 스팸"을 내려주는 API → 위반 (제3조)
- 본사가 "국가별 스팸 패턴"을 사전 매핑 → 위반
- 본사가 사용자 행동 로그를 수집 → 위반 (제1조)

### 7-4. 허용 구현 패턴

- 디바이스 Room DB(NKB)에 번호별 판단 결과 저장 → 허용 (디바이스 내부)
- 일반 검색 엔진에 번호 조회 → 허용 (검색 엔진은 제3자가 아닌 공개 인프라)
- 공공 공신력 API (KISA·경찰청·금감원) 조회 → 허용 (정부 공공 데이터)
- 스토어 공식 API (Play Billing·StoreKit 2) 호출 → 허용 (스토어 자체)
- Firebase Crashlytics·Analytics·FCM → 허용 (써드파티 관찰·전달 인프라, 사용자 데이터 수집 목적 아님)

v1.3 본문에 산재했던 "디바이스=자가발전기" 원칙을 v1.6에서 7조로 조문화. 메모리 헌법 7대 원칙(In-Bound Zero, Out-Bound Zero, 자율 작동 등)과 완전 정합.

---

## 1-1. 헌법 7조 상호 정합 표

모든 설계 결정은 7조 중 **어느 조항에 해당하는가**를 식별할 수 있어야 한다. 복수 조항 해당 시 모두 준수해야 한다.

| 설계 결정 | 해당 조항 |
|---|---|
| 통화 번호를 디바이스에만 저장 | 1조 (Out-Bound Zero) |
| 검색 결과 스니펫을 메모리 후 즉시 폐기 | 2조 (In-Bound Zero) |
| NKB Miss 시 본사 fallback 금지 | 3조 (결정권 중앙집중 금지) |
| 네트워크 단절 시 NKB Hit만으로 4속성 출력 | 4조 (자가 작동 L3) |
| 폐기된 설계안을 문서에 실명 기록 | 5조 (정직성) |
| net ARPU $1.49 측정·공개 | 6조 (가격 정직성) |
| 본사 운영 0 / 매핑 0 / 데이터센터 0 | 7조 (디바이스 오리엔티드 거위) |
| 스토어 빌링만 사용, 자체 영수증 검증 서버 금지 | 1조 + 7조 |
| Google Programmable Search API 사용 | 1조 (제3자 아님, 공개 검색 인프라) |
| 일반 검색 쿼리에 사용자 번호 포함 | 1조 (공개 번호이므로 사용자 데이터 아님) |

## 1-2. 헌법 위반 판정 SOP

1. 설계·코드·문서 제출 시 자가 점검 체크리스트 실행 (7조 각각 Y/N).
2. 1개라도 N → 설계 폐기 또는 재작성.
3. Y/N 판정이 애매한 경우 → 비전에게 판정 요청 (§17 Rule 3).
4. 비전도 불명확 → 대표님에게 판정 요청.
5. 판정 결과는 0-B 감사 로그에 기록.

### 24-6-1. Manifest 권한 정합 (Patch 36 재작성 — QUERY_ALL_PACKAGES 제거 + `<queries>` 블록)

**변경 사유**: Patch 26(v1.6.1-patch)에서 `QUERY_ALL_PACKAGES`를 `tools:ignore`로 선언했으나, 자비스 Lane 4(2026-04-24) 검증 결과 **Play 심사 거의 100% 리젝 대상**. 자비스 대안 2 "Package Visibility 최소화"를 수용, `QUERY_ALL_PACKAGES` 제거하고 `<queries>` 블록으로 대체한다 (Patch 36).

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
          xmlns:tools="http://schemas.android.com/tools">

    <!-- CallCheck 필수 권한 -->
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />

    <!-- MessageCheck Mode A 전용 (사용자가 Default SMS 지정 시에만 활성) -->
    <uses-permission android:name="android.permission.READ_SMS" />
    <uses-permission android:name="android.permission.RECEIVE_SMS" />
    <uses-permission android:name="android.permission.SEND_SMS" />
    <uses-permission android:name="android.permission.WRITE_SMS"
        tools:ignore="ProtectedPermissions" />

    <!-- 네트워크 · SLA · 알림 · 오버레이 -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <!-- MicCheck/CameraCheck용 사용 통계 (Special App Access, 사용자 수동 승인) -->
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS"
        tools:ignore="ProtectedPermissions" />

    <!-- Patch 36: QUERY_ALL_PACKAGES 제거 → <queries> 블록으로 대체 -->
    <queries>
        <!-- MicCheck: RECORD_AUDIO를 선언한 앱만 필터링 -->
        <intent>
            <action android:name="android.intent.action.MAIN" />
        </intent>

        <!-- Intent 기반 방식: 특정 action에 응답하는 앱만 조회 -->
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="http" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>

        <!-- MessageCheck Share Intent (Mode B) 대상 식별 -->
        <intent>
            <action android:name="android.intent.action.SEND" />
            <data android:mimeType="text/plain" />
        </intent>
    </queries>

    <!-- 금지 권한 (정책 위반 또는 Patch로 제거됨) -->
    <!-- ❌ BROADCAST_SMS — Play 정책 위반 (Patch 17) -->
    <!-- ❌ RECORD_AUDIO — MicCheck는 스캔만, 녹음 안 함 (Patch 23) -->
    <!-- ❌ CAMERA — CameraCheck는 스캔만, 촬영 안 함 (Patch 23) -->
    <!-- ❌ QUERY_ALL_PACKAGES — Play 심사 리스크, <queries>로 대체 (Patch 36) -->
</manifest>
```

**핵심 변경점 (Patch 36)**:

1. **`QUERY_ALL_PACKAGES` 완전 제거** — Android 11+ Package Visibility 정책 정면 준수.
2. **`<queries>` 블록 신설** — MicCheck/CameraCheck는 "RECORD_AUDIO / CAMERA 선언 앱"만 필터링 (PackageManager.getPackagesHoldingPermissions 사용 시 자동 처리).
3. **SMS 권한 4종 추가** — Mode A(Default SMS) 활성화 시에만 사용자 동의로 부여.
4. **PACKAGE_USAGE_STATS 유지** — Special App Access(사용자 수동 설정) 경로로 부여.
5. **네트워크 · 알림 · 오버레이** — 기존 유지.

**Permissions Declaration 연결**: 위 권한 목록 각각의 core user benefit 선언은 §27-3 참조.
